# NGC-Lightning-Grid-Workshop
A workshop that walks through how to get started with Grid, NGC and PyTorch Lightning to supercharge deep learning.
